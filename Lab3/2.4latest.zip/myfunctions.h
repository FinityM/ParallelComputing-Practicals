void meanFunction(float *mean, float *array, int arrsize);
void sDeviate(float *stdev, float *array, int size, float mean);
