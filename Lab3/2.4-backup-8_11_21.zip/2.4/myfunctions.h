float meanFunction(float *array, int am);
float sDeviate(float *array, int size, float mean);
